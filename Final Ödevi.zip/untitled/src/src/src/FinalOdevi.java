package src.src;

public class FinalOdevi {
    public static void main(String args[]) {
        Muhendis muh = new Muhendis();
        Doktor dok = new Doktor();
        Ogretmen ogrt = new Ogretmen();

        System.out.println("***Mühendis Bilgisi***\n");
        muh.ad ="Metehan ";
        muh.soyad ="Gökboğa";
        muh.dogumyili =2001;
        muh.muhAlan ="Bilgisayar";
        muh.uzmAlani ="Web";
        muh.baslamaYili =2021;
        muh.maas =2500;
        muh.Bilgi();
        muh.Zam(80);

        System.out.println("\n***Doktor Bilgisi***\n");
        dok.ad ="Salih";
        dok.soyad ="Önal";
        dok.dogumyili =1986;
        dok.dokAlani ="Egitim Arastirma";
        dok.uzmAlani ="KBB";
        dok.ameliyatSayisi = 13;
        dok.baslamaYili =2016;
        dok.maas =7000;
        dok.Bilgi();

        System.out.println("\n***Öğretmen Bilgisi***\n");
        ogrt.ad ="Ahmet Hakan";
        ogrt.soyad ="Demir";
        ogrt.dogumyili =1997;
        ogrt.dersSaati = 50;
        ogrt.brans ="Tarih";
        ogrt.baslamaYili =2020;
        ogrt.maas =3000;
        ogrt.Bilgi();

    }
}


